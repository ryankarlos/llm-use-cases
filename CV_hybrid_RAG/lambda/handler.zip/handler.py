"""Lambda handler for CV Matcher API with GraphRAG integration.

Uses AWS GraphRAG Toolkit lexical-graph for graph-enhanced retrieval.
Falls back to skill-based matching when GraphRAG is unavailable.
"""

import json
import logging
import os
from typing import Any, Dict, List, Set

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Environment config
NEPTUNE_ENDPOINT = os.environ.get("NEPTUNE_ENDPOINT", "")
OPENSEARCH_ENDPOINT = os.environ.get("OPENSEARCH_ENDPOINT", "")
AWS_REGION = os.environ.get("AWS_REGION_NAME", "us-east-1")

# Skill relationships for fallback matching
RELATED_SKILLS: Dict[str, Set[str]] = {
    "Python": {"Java", "R", "Scala"},
    "Machine Learning": {"Deep Learning", "AI", "Data Science", "Statistics"},
    "Deep Learning": {"Machine Learning", "TensorFlow", "PyTorch"},
    "TensorFlow": {"PyTorch", "Keras", "Deep Learning"},
    "PyTorch": {"TensorFlow", "Keras", "Deep Learning"},
    "SQL": {"NoSQL", "PostgreSQL", "MySQL"},
    "AWS": {"Azure", "GCP", "Cloud"},
    "Docker": {"Kubernetes", "Containers"},
    "Kubernetes": {"Docker", "K8s"},
    "ETL": {"Data Pipelines", "Airflow"},
    "MLOps": {"DevOps", "CI/CD"},
    "Terraform": {"Infrastructure as Code", "CloudFormation"},
    "Cloud Architecture": {"AWS", "Azure", "GCP"},
}

# Job roles
JOB_ROLES = {
    "data_scientist": {
        "title": "Data Scientist",
        "required_skills": ["Python", "Machine Learning", "Statistics", "SQL", "Data Analysis"],
        "preferred_skills": ["Deep Learning", "NLP", "TensorFlow", "PyTorch"],
        "min_experience_years": 3
    },
    "data_engineer": {
        "title": "Data Engineer",
        "required_skills": ["Python", "SQL", "ETL", "Data Pipelines", "AWS"],
        "preferred_skills": ["Spark", "Airflow", "Kafka", "Terraform"],
        "min_experience_years": 3
    },
    "ml_engineer": {
        "title": "Machine Learning Engineer",
        "required_skills": ["Python", "Machine Learning", "MLOps", "Docker", "AWS"],
        "preferred_skills": ["Kubernetes", "SageMaker", "MLflow"],
        "min_experience_years": 4
    },
    "cloud_architect": {
        "title": "Cloud Architect",
        "required_skills": ["AWS", "Cloud Architecture", "Infrastructure as Code", "Security", "Networking"],
        "preferred_skills": ["Terraform", "Kubernetes", "Serverless"],
        "min_experience_years": 5
    }
}

# Sample candidates
CANDIDATES = [
    {"id": "cand_001", "name": "Sarah Chen", "skills": ["Python", "Machine Learning", "Statistics", "SQL", "TensorFlow", "Deep Learning", "NLP", "Data Analysis"], "experience_years": 5},
    {"id": "cand_002", "name": "Marcus Johnson", "skills": ["Python", "SQL", "ETL", "Data Pipelines", "AWS", "Spark", "Airflow", "Kafka"], "experience_years": 4},
    {"id": "cand_003", "name": "Emily Rodriguez", "skills": ["Python", "Machine Learning", "MLOps", "Docker", "AWS", "Kubernetes", "SageMaker", "MLflow"], "experience_years": 6},
    {"id": "cand_004", "name": "David Kim", "skills": ["AWS", "Cloud Architecture", "Infrastructure as Code", "Security", "Terraform", "Kubernetes", "Networking"], "experience_years": 7},
    {"id": "cand_005", "name": "Priya Patel", "skills": ["Python", "Machine Learning", "Statistics", "R", "Data Analysis", "Computer Vision"], "experience_years": 3},
    {"id": "cand_006", "name": "James Wilson", "skills": ["Python", "SQL", "AWS", "Docker", "ETL", "dbt", "Snowflake"], "experience_years": 2},
    {"id": "cand_007", "name": "Lisa Thompson", "skills": ["Python", "Machine Learning", "Deep Learning", "PyTorch", "NLP", "Statistics", "SQL"], "experience_years": 4},
    {"id": "cand_008", "name": "Ahmed Hassan", "skills": ["AWS", "Azure", "Cloud Architecture", "Security", "Networking", "Serverless"], "experience_years": 5},
]


class GraphRAGService:
    """GraphRAG service using AWS GraphRAG Toolkit lexical-graph."""
    
    def __init__(self):
        self._initialized = False
        self._graph_store = None
        self._vector_store = None
        self._query_engine = None
    
    def initialize(self) -> bool:
        """Initialize GraphRAG with Neptune and OpenSearch."""
        if not NEPTUNE_ENDPOINT or not OPENSEARCH_ENDPOINT:
            logger.warning("Neptune/OpenSearch endpoints not configured")
            return False
        
        try:
            from graphrag_toolkit import LexicalGraphQueryEngine
            from graphrag_toolkit.storage import GraphStoreFactory, VectorStoreFactory
            
            # Connect to Neptune Database
            self._graph_store = GraphStoreFactory.for_graph_store(
                f"neptune-db://{NEPTUNE_ENDPOINT}"
            )
            
            # Connect to OpenSearch Serverless
            self._vector_store = VectorStoreFactory.for_vector_store(
                f"aoss://{OPENSEARCH_ENDPOINT}"
            )
            
            # Create query engine for traversal-based search
            self._query_engine = LexicalGraphQueryEngine.for_traversal_based_search(
                self._graph_store,
                self._vector_store
            )
            
            self._initialized = True
            logger.info("GraphRAG initialized successfully")
            return True
            
        except ImportError as e:
            logger.warning(f"GraphRAG toolkit not available: {e}")
            return False
        except Exception as e:
            logger.error(f"Failed to initialize GraphRAG: {e}")
            return False
    
    def find_candidates(self, job: Dict, top_k: int = 10) -> List[Dict]:
        """Find candidates using graph-enhanced retrieval."""
        if not self._initialized:
            return []
        
        try:
            query = f"""Find candidates matching the {job['title']} role.
Required skills: {', '.join(job['required_skills'])}.
Preferred skills: {', '.join(job.get('preferred_skills', []))}.
Minimum experience: {job['min_experience_years']} years."""
            
            response = self._query_engine.query(query)
            
            # Parse response to extract candidate matches
            results = []
            if hasattr(response, 'source_nodes'):
                for node in response.source_nodes[:top_k]:
                    meta = node.metadata or {}
                    if meta.get('doc_type') == 'cv':
                        results.append({
                            "candidate_id": meta.get('candidate_id', ''),
                            "candidate_name": meta.get('candidate_name', 'Unknown'),
                            "match_score": node.score * 100 if hasattr(node, 'score') else 50.0,
                            "graph_context": meta.get('skills', '').split(','),
                            "explanation": str(response.response)[:200] if hasattr(response, 'response') else ""
                        })
            
            return results
            
        except Exception as e:
            logger.error(f"GraphRAG query failed: {e}")
            return []


# Global GraphRAG service instance
_graphrag_service = None


def get_graphrag_service() -> GraphRAGService:
    """Get or create GraphRAG service singleton."""
    global _graphrag_service
    if _graphrag_service is None:
        _graphrag_service = GraphRAGService()
        _graphrag_service.initialize()
    return _graphrag_service


def calculate_match_score(candidate: Dict, job: Dict) -> Dict[str, Any]:
    """Calculate match score: 50% direct + 30% related + 20% experience."""
    required = job["required_skills"]
    cand_skills = candidate["skills"]
    cand_lower = {s.lower() for s in cand_skills}
    
    # Direct matches
    direct = [s for s in required if s.lower() in cand_lower]
    direct_score = (len(direct) / len(required) * 100) if required else 0
    
    # Related matches
    missing = set(required) - set(direct)
    related = []
    for skill in missing:
        if any(r.lower() in cand_lower for r in RELATED_SKILLS.get(skill, set())):
            related.append(skill)
    related_score = (len(related) / len(missing) * 100) if missing else 100
    
    # Experience score
    min_exp = job["min_experience_years"]
    exp_score = 100.0 if candidate["experience_years"] >= min_exp else (
        (candidate["experience_years"] / min_exp * 100) if min_exp > 0 else 100
    )
    
    # Skill gaps and transferable
    gaps = [s for s in required if s.lower() not in cand_lower]
    transferable = []
    req_lower = {s.lower() for s in required}
    pref_lower = {s.lower() for s in job.get("preferred_skills", [])}
    for skill in cand_skills:
        if skill.lower() not in req_lower and skill.lower() not in pref_lower:
            for req in required:
                if skill in RELATED_SKILLS.get(req, set()):
                    transferable.append(skill)
                    break
    
    total = max(0.0, min(100.0, direct_score * 0.5 + related_score * 0.3 + exp_score * 0.2))
    
    return {
        "candidate_id": candidate["id"],
        "candidate_name": candidate["name"],
        "match_score": round(total, 1),
        "direct_matches": direct,
        "related_matches": related,
        "skill_gaps": gaps,
        "transferable_skills": transferable,
        "experience_years": candidate["experience_years"]
    }


def match_with_graphrag(job: Dict) -> List[Dict]:
    """Match candidates using GraphRAG, fall back to skill-based if unavailable."""
    service = get_graphrag_service()
    
    # Try GraphRAG first
    if service._initialized:
        graph_results = service.find_candidates(job)
        if graph_results:
            # Enhance graph results with skill-based scoring
            enhanced = []
            for gr in graph_results:
                cand = next((c for c in CANDIDATES if c["id"] == gr["candidate_id"]), None)
                if cand:
                    skill_match = calculate_match_score(cand, job)
                    # Combine graph score (40%) with skill score (60%)
                    combined_score = gr["match_score"] * 0.4 + skill_match["match_score"] * 0.6
                    skill_match["match_score"] = round(combined_score, 1)
                    skill_match["graph_enhanced"] = True
                    skill_match["graph_context"] = gr.get("graph_context", [])
                    enhanced.append(skill_match)
            if enhanced:
                enhanced.sort(key=lambda x: -x["match_score"])
                return enhanced
    
    # Fallback to skill-based matching
    results = [calculate_match_score(c, job) for c in CANDIDATES]
    for r in results:
        r["graph_enhanced"] = False
    results.sort(key=lambda x: -x["match_score"])
    return results


def handler(event: Dict, context: Any) -> Dict:
    """Lambda handler for CV Matcher API."""
    logger.info(f"Event: {json.dumps(event)}")
    
    path = event.get("path", event.get("rawPath", "/"))
    body = {}
    if event.get("body"):
        body = json.loads(event["body"]) if isinstance(event["body"], str) else event["body"]
    
    try:
        if path.endswith("/jobs"):
            return response(200, {"jobs": list(JOB_ROLES.keys()), "details": JOB_ROLES})
        
        elif path.endswith("/candidates"):
            return response(200, {"candidates": CANDIDATES})
        
        elif path.endswith("/match"):
            role_id = body.get("role_id") or (event.get("queryStringParameters") or {}).get("role_id")
            if not role_id or role_id not in JOB_ROLES:
                return response(400, {"error": f"Invalid role_id. Available: {list(JOB_ROLES.keys())}"})
            
            job = JOB_ROLES[role_id]
            results = match_with_graphrag(job)
            
            return response(200, {
                "job": {"role_id": role_id, **job},
                "matches": results,
                "graphrag_enabled": get_graphrag_service()._initialized
            })
        
        elif path.endswith("/compare"):
            cand1_id, cand2_id, role_id = body.get("candidate1_id"), body.get("candidate2_id"), body.get("role_id")
            if not all([cand1_id, cand2_id, role_id]):
                return response(400, {"error": "Required: candidate1_id, candidate2_id, role_id"})
            
            cand1 = next((c for c in CANDIDATES if c["id"] == cand1_id), None)
            cand2 = next((c for c in CANDIDATES if c["id"] == cand2_id), None)
            job = JOB_ROLES.get(role_id)
            
            if not all([cand1, cand2, job]):
                return response(404, {"error": "Candidate or job not found"})
            
            return response(200, {
                "job": {"role_id": role_id, **job},
                "candidate1": calculate_match_score(cand1, job),
                "candidate2": calculate_match_score(cand2, job)
            })
        
        elif path.endswith("/health"):
            service = get_graphrag_service()
            return response(200, {
                "status": "healthy",
                "graphrag_enabled": service._initialized,
                "neptune_endpoint": NEPTUNE_ENDPOINT,
                "opensearch_endpoint": OPENSEARCH_ENDPOINT
            })
        
        elif path.endswith("/index"):
            # Index candidates into GraphRAG (POST only)
            service = get_graphrag_service()
            if not service._initialized:
                return response(503, {"error": "GraphRAG not initialized"})
            
            # Index would happen here - requires graphrag_toolkit LexicalGraphIndex
            return response(200, {"message": "Indexing endpoint - implement with LexicalGraphIndex"})
        
        else:
            return response(404, {"error": "Not found", "endpoints": ["/jobs", "/candidates", "/match", "/compare", "/health", "/index"]})
    
    except Exception as e:
        logger.error(f"Error: {str(e)}")
        return response(500, {"error": str(e)})


def response(status_code: int, body: Dict) -> Dict:
    return {
        "statusCode": status_code,
        "headers": {"Content-Type": "application/json", "Access-Control-Allow-Origin": "*",
                    "Access-Control-Allow-Methods": "GET, POST, OPTIONS", "Access-Control-Allow-Headers": "Content-Type"},
        "body": json.dumps(body)
    }
